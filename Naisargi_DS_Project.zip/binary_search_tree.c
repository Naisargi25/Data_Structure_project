#include<stdio.h>
#include<stdlib.h>

struct node
{
  int info;
  struct node *l;
  struct node *r;
};

struct node* createNode(int);
struct node* insert(struct node *,int);
struct node* search(struct node *,int);
struct node* delete(struct node *,int);
void inOrder(struct node *);
int getRightMin(struct node *);

void main()
{
  struct node *root;
  /*printf("Enter elements :\n");
  int a[10];
  for(int i=0;i<=9;i++)
  {
    scanf("%d",&a[i]);
  }*/
  root=createNode(50);
  insert(root,25);
  insert(root,75);
  insert(root,22);
  insert(root,40);
  insert(root,60);
  insert(root,80);
  insert(root,90);
  insert(root,15);
  insert(root,30);
  
  printf("\nInput is :\n");
  printf("50 25 75 22 40 60 80 90 15 30");
  printf("\n\nInorder traversal of binary search tree is :\n"); // sample ip - 50 25 75 22 40 60 80 90 15 30
  inOrder(root);
  printf("\n\nSearch an element %d\n",80);
  search(root,80);
  printf("\nSearch an element %d\n",70);
  search(root,70);
  root = delete(root,15);
  printf("\nAfter deletion of %d, the new tree is :\n",15);
  inOrder(root);
  printf("\nDone\n\n");
}

struct node* createNode(int data)
{
   struct node *new;
   new = (struct node *)malloc(sizeof(struct node));
   new->info=data;
   new->l=new->r=NULL;
   return new;
}

struct node* insert(struct node *root,int data)
{
  if(root==NULL)
  {
    return createNode(data);
  }
  else if(data > root->info)
  {
    root->r=insert(root->r,data);
  }
  else
  {
    root->l=insert(root->l,data);
  }
  return root;
}


struct node* search(struct node *root,int key)
{
  struct node *temp=root;
  printf("Visiting elements : ");
  while(temp->info!=key)
  {
    if(temp!=NULL)
    {
       printf("%d ",temp->info);
       if(temp->info>key)
       {
         temp=temp->l;
       }
       else
       {
          temp=temp->r;
       }
       if(temp==NULL)
       {
          printf("\nNode not found\n");
          return NULL;
       }
    }
  }
  printf("\nNode found\n");
  return temp;
}
void inOrder(struct node *t)
 {
    if(t==NULL)
    {
      printf("Empty Tree\n");
    }
    else
    {
      if(t->l!=NULL)
      {
        inOrder(t->l);
      }
      printf("%d ",t->info);
      if(t->r!=NULL)
      {
        inOrder(t->r);
      }
    }
 }
 
 int getRightMin(struct node *root)
 {
    struct node *temp = root;
    while(temp->l!=NULL)
    {
      temp = temp->l;
    }
    return temp->info;
 }
 
 struct node* delete(struct node *root,int key)
 {
   if(root==NULL)
   {
     return NULL;
   }
   
   if(key < root->info)
   {
     root->l = delete(root->l,key);
   }
   
   else if(key > root->info)
   {
     root->r = delete(root->r,key);
   }
   
   else
   {
     if(root->l==NULL && root->r==NULL)
     {
       free(root);
       return NULL;
     }
     else if(root->l==NULL)
     {
       struct node *temp = root->r;
       free(root);
       return temp;
     }
     else if(root->r==NULL)
     {
       struct node *temp = root->l;
       free(root);
       return temp;
     }
     
     else
     {
        int rightMin = getRightMin(root->r);
        root->info = rightMin;
        root->r = delete(root->r,rightMin);
     }
   }
   return root;
 }
