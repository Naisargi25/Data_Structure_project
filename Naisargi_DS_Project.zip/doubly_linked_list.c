#include<stdio.h>
#include<stdlib.h>


struct node
{
  int info;
  struct node *left;
  struct node *right;
};

struct node* insertm(int,struct node *,struct node *,struct node *);
struct node* delete(int,struct node *);

void main()
{
   struct node *first, *second, *third;
   first = (struct node *)malloc(sizeof(struct node));
   second = (struct node *)malloc(sizeof(struct node));
   third = (struct node *)malloc(sizeof(struct node));
   
   
   first->info=2;
   first->left=NULL;
   first->right=second;
   second->info=4;
   second->left=first;
   second->right=third;
   third->info=6;
   third->left=second;
   third->right=NULL;
   
   printf("Original Doubly linked list is :\n");
   display(first);
   first=insertm(1,first,third,first);
   printf("\nAfter insertion at first position\n");
   display(first);
   first=insertm(8,first,third,third);
   printf("\nAfter insertion at last position\n");
   display(first);
   first=insertm(3,first,third,second);
   printf("\nAfter insertion at middle\n");
   display(first);
   first=delete(1,first);
   printf("\nAfter deleting first node doubly linked list is :\n");
   display(first);
   first=delete(8,first);
   printf("\nAfter deleting last node doubly linked list is :\n");
   display(first);
   first=delete(3,first);
   printf("\nAfter deleting random node doubly linked list is :\n");
   display(first);
}

void display(struct node *first)
{
  struct node *save;
  save=first;
  while(save!=NULL)
  {
     printf("%d ",save->info);
     save=save->right;
  }
  printf("\n");
}
   
 struct node* insertm(int x,struct node *first,struct node *third,struct node *second)
 {
   
   struct node *new;
   new = (struct node *)malloc(sizeof(struct node));
   new->info=x;
   
   if(third==NULL) // insert into an empty list
   {
      new->left=NULL;
      new->right=NULL;
      first=third=new;
      return first;
   }
   
   else if(second==first) // left most insertion(front)
   {
      new->left=NULL;
      new->right=second;
      second->left=new;
      return new;
   }
   
   else if(second==third) // left most insertion(front)
   {
      new->right=NULL;
      new->left=second;
      second->right=new;
      third=new;
      return first;
   }
   
   else // insertion in the middle
   {
      new->left=second->left;
      new->right=second;
      second->left=new;
      new->left->right=new;
      return first;
   }
     
 }

struct node* delete(int del,struct node* first)
{
    struct node *save,*pred,*new;
    new=(struct node*)malloc(sizeof(struct node));
 
    save=first;
    if(del!=first->info)
    {
      while(save!=NULL && save->info!=del)
      {		
	save=save->right;
      }

      if(save->right!=NULL)
      {
        save->right->left=save->left;
      }
      if(save->left!=NULL)
      {
        save->left->right=save->right;
      }
      
      free(save);
    }

   else
   {
      first=first->right;//first node deleted
   } 

  return first;
}





