#include<stdio.h>
#include<stdlib.h>


struct node
{
  int info;
  struct node *link;
};

struct node1
{
  int field;
  struct node1 *ptr;
};

struct node* insertfirst(int,struct node *);
struct node* insertend(int,struct node *);
struct node* insertorder(int, struct node *);
struct node* delete(int,struct node *);
struct node* copy(struct node *);
void display(struct node *);
void display1(struct node1 *);
void count(struct node *);

void main()
{
   int ele,choice;
   struct node *first, *second, *third;
   struct node1 *begin;
   first = (struct node *)malloc(sizeof(struct node));
   second = (struct node *)malloc(sizeof(struct node));
   third = (struct node *)malloc(sizeof(struct node));
   
   first->info=3;
   first->link=second;
   second->info=5;
   second->link=third;
   third->info=6;
   third->link=NULL;
   
   printf("Linked list is :\n");
   display(first);
   while(choice!=8)
   {
     printf("\n***********Single Linked List**********\n");
     printf("\n1.Insert at first position\n2.Insert at last position\n3.Insert at middle\n4.Delete a node\n5.Copy linked list\n6.Display\n7.Count no. of nodes\n8.Quit\n");
     printf("Enter your choice :\n");
     scanf("%d",&choice);
     switch(choice)
     {
        case 1:
          printf("Enter an element : ");
          scanf("%d",&ele);
          first = insertfirst(ele,first);
          break;
          
        case 2:
          printf("Enter an element : ");
          scanf("%d",&ele);
          first = insertend(ele,first);
          break;
          
        case 3:
          printf("Enter an element : ");
          scanf("%d",&ele);
          first = insertorder(ele,first);
          break;
          
        case 4:
          printf("Enter an element : ");
          scanf("%d",&ele);
          first = delete(ele,first);
          break;
          
        case 5:
          first = copy(first);
          printf("After copy linked list is :\n");
          display1(first);
          break;
          
        case 6:
          printf("Linked list is :\n");
          display(first);
          break; 
          
        case 7:
          count(first);
          break;
          
       case 8:
           printf("Thank You...!!\n");
           
     }
   }
 }  
 void display(struct node *first)
{
  struct node *save;
  save=first;
  while(save!=NULL)
  {
     printf("%d ",save->info);
     save=save->link;
  }
  printf("\n");
}
void display1(struct node1 *begin)
{
  struct node1 *save;
  save=begin;
  do
  {
     printf("%d ",save->field);
     save=save->ptr;
  }while(save!=NULL);
  printf("\n");
}

void count(struct node *first)
{
  struct node *save;
  int c=0;
  save=first;
  while(save!=NULL)
  {
     c+=1;
     save=save->link;
  }
  printf("Total no. of node in the linked list is : %d\n",c);
  //printf("\n");
}

struct node* insertfirst(int x,struct node *first)
{
   struct node *new;
   new = (struct node *)malloc(sizeof(struct node));
   if(new==NULL)
   {
     printf("Overflow\n");
     return 0;
   }
   else
   {
      new->info=x;
      new->link=first;
      first=new;
      return first;
   }
 }

struct node* insertend(int x,struct node *first)
{
   struct node *new,*temp;

   new = (struct node *)malloc(sizeof(struct node));
   new->info=x;
   new->link=NULL;
   
   if(first==NULL)
   {
      return new;
   }
   
   temp=first;
   
   while(temp->link!=NULL)
   {
      temp=temp->link;
   }
   temp->link=new;
   return first;
 }  

struct node* insertorder(int x,struct node *first)
{
   struct node *new,*temp;

   new = (struct node *)malloc(sizeof(struct node));
   new->info=x;
 
   if(first==NULL)
   {
      new->link=NULL;
      return new;
   }
   
   else if(new->info <= first->info)
   {
     new->link=first;
     return new;
   }
   
   temp=first;
   while(temp->link!=NULL && new->info >= temp->link->info)
   {
      temp=temp->link;
   } 
   
   new->link=temp->link;
   temp->link=new;
   
   return first;  
   
}

struct node* delete(int x,struct node *first)
{
   struct node *temp;
   if(first==NULL)
   {
      printf("Underflow\n");
   }
   temp=first;
   if(temp->info==x)
   {
     free(temp);
     return first;
   }
   
   while(temp->link!=NULL)
   {
     if(temp->link->info==x)
     {
       temp->link=temp->link->link;
       return first;
     }
     temp=temp->link;
   }
   printf("Node not found\n");
   return first;  
}

struct node* copy(struct node *first)
{
   if(first==NULL)
   {
     return NULL;
   }
   struct node *save;
   struct node1 *begin,*pred,*new;
   new = (struct node1 *)malloc(sizeof(struct node1));
   new->field=first->info;
   save=first;
   begin = new;
   while(save->link!=NULL)
   {

      pred=new;
      save=save->link;
      new = (struct node *)malloc(sizeof(struct node));
      new->field=save->info;
      pred->ptr=new;
   }
   new->ptr=NULL;
   return begin;
     
}
  
   
   
   
   
